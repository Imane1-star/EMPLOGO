
package com.transportpro.dao;

import com.transportpro.model.Affectation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AffectationDAO {

    // Récupérer toutes les affectations
    public List<Affectation> findAll() throws SQLException {

        List<Affectation> list = new ArrayList<>();

        String sql = """
            SELECT id_affectation, id_trajet, id_bus,
                   id_chauffeur, date_trajet, heure_depart,
                   heure_arrivee, statut
            FROM affectation
            ORDER BY date_trajet, heure_depart
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Date date = rs.getDate("date_trajet");
                Time depart = rs.getTime("heure_depart");
                Time arrivee = rs.getTime("heure_arrivee");

                Affectation a = new Affectation(
                    rs.getInt("id_trajet"),
                    rs.getInt("id_bus"),
                    rs.getInt("id_chauffeur"),
                    date.toLocalDate(),
                    depart.toLocalTime(),
                    arrivee.toLocalTime(),
                    rs.getString("statut")
                );

                a.setIdAffectation(
                    rs.getInt("id_affectation")
                );

                list.add(a);
            }
        }

        return list;
    }

    // Ajouter une affectation
    public int insert(Affectation a) throws SQLException {

        String sql = """
            INSERT INTO affectation
            (id_trajet, id_bus, id_chauffeur,
             date_trajet, heure_depart, heure_arrivee, statut)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, a.getIdTrajet());
            ps.setInt(2, a.getIdBus());
            ps.setInt(3, a.getIdChauffeur());
            ps.setDate(4, Date.valueOf(a.getDateTrajet()));
            ps.setTime(5, Time.valueOf(a.getHeureDepart()));
            ps.setTime(6, Time.valueOf(a.getHeureArrivee()));
            ps.setString(7, a.getStatut());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    a.setIdAffectation(id);
                    return id;
                }
            }
        }

        return -1;
    }

    // Compter les inscriptions confirmées d'un trajet
    // rejectionbecause the bus cannot accommodate all employees
    public int countConfirmedInscriptions(int idTrajet)
            throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM inscription i
            JOIN affectation a
                ON i.id_affectation = a.id_affectation
            WHERE a.id_trajet = ?
            AND i.statut = 'CONFIRMEE'
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, idTrajet);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        return 0;
    }


    // Vérifier la disponibilité et la capacité du bus
    public boolean busDisponibleEtSuffisant(
            int idBus, int nombreEmployes) throws SQLException {

        String sql = """
            SELECT capacite
            FROM bus
            WHERE id_bus = ?
            AND statut = 'DISPONIBLE'
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, idBus);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    int capacite = rs.getInt("capacite");

                    return capacite >= nombreEmployes;
                }
            }
        }

        return false;
    }



    // Vérifier si le chauffeur est disponible
    public boolean chauffeurDisponible(int idChauffeur)
            throws SQLException {

        String sql = """
            SELECT statut, validite_permis
            FROM chauffeur
            WHERE id_chauffeur = ?
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, idChauffeur);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    String statut = rs.getString("statut");
                    Date validite = rs.getDate("validite_permis");

                    return "ACTIF".equals(statut)
                            && validite != null
                            && !validite.toLocalDate()
                                .isBefore(java.time.LocalDate.now());
                }
            }
        }

        return false;
    }


    // Vérifier les conflits entre les affectations
    public boolean hasConflit(
            int idBus,
            int idChauffeur,
            java.time.LocalDate date,
            java.time.LocalTime heureDepart,
            java.time.LocalTime heureArrivee)
            throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM affectation
            WHERE date_trajet = ?
            AND statut IN ('PLANIFIEE', 'EN_COURS', 'TERMINEE')
            AND (id_bus = ? OR id_chauffeur = ?)
            AND heure_depart < ?
            AND heure_arrivee > ?
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(date));
            ps.setInt(2, idBus);
            ps.setInt(3, idChauffeur);
            ps.setTime(4, Time.valueOf(heureArrivee));
            ps.setTime(5, Time.valueOf(heureDepart));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false;
    }

}
