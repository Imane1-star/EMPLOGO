
package com.transportpro.dao;

import com.transportpro.model.Chauffeur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChauffeurDAO {

    public List<Chauffeur> findAll() throws SQLException {

        List<Chauffeur> list = new ArrayList<>();

        String sql = """
            SELECT c.id_chauffeur,
                   e.nom,
                   e.telephone,
                   c.numero_permis,
                   c.statut
            FROM chauffeur c
            INNER JOIN employe e
                ON c.id_employe = e.id_employe
            ORDER BY c.id_chauffeur
            """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                boolean disponible =
                    "ACTIF".equals(rs.getString("statut"));

                list.add(new Chauffeur(
                    rs.getInt("id_chauffeur"),
                    rs.getString("nom"),
                    rs.getString("telephone"),
                    rs.getString("numero_permis"),
                    disponible
                ));
            }
        }

        return list;
    }
}
