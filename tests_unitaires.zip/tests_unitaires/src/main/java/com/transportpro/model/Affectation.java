
package com.transportpro.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Affectation {

    private int idAffectation;
    private int idTrajet;
    private int idBus;
    private int idChauffeur;
    private LocalDate dateTrajet;
    private LocalTime heureDepart;
    private LocalTime heureArrivee;
    private String statut;

    public Affectation(int idTrajet, int idBus, int idChauffeur,
                       LocalDate dateTrajet, LocalTime heureDepart,
                       LocalTime heureArrivee, String statut) {
        this.idTrajet = idTrajet;
        this.idBus = idBus;
        this.idChauffeur = idChauffeur;
        this.dateTrajet = dateTrajet;
        this.heureDepart = heureDepart;
        this.heureArrivee = heureArrivee;
        this.statut = statut;
    }

    public int getIdAffectation() {
        return idAffectation;
    }

    public void setIdAffectation(int idAffectation) {
        this.idAffectation = idAffectation;
    }

    public int getIdTrajet() {
        return idTrajet;
    }

    public int getIdBus() {
        return idBus;
    }

    public int getIdChauffeur() {
        return idChauffeur;
    }

    public LocalDate getDateTrajet() {
        return dateTrajet;
    }

    public LocalTime getHeureDepart() {
        return heureDepart;
    }

    public LocalTime getHeureArrivee() {
        return heureArrivee;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }
}
